public class Main {
    public static void main(String[] args) {
        Student Student = new Student();
        Student.addStudent(new Student("drake", "afflack", "Drake Afflack", "computer science",
                "2nd", 3.9, "comp 120, comp 121, data structeres"));
        Student.addStudent(new Student("emily", "danviso", "Emily Danviso", "Business",
                "15th", 3.1, "finance, human resource, market research"));
        System.out.println(Student);
        Student.addStudent(new Student("drake", "afflack", "Drake Afflack", "computer science",
                "2nd", 3.9, "comp 120, comp 121"));
        Student.addStudent(new Student("emily", "danviso", "Emily Danviso", "Business",
                "15th", 3.1, "finance, human resource"));
        System.out.println(Student);
    }
}