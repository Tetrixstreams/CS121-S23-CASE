import java.util.LinkedList;
import java.util.Scanner;
java.util.LinkedList
public class Student {

        Scanner console = new Scanner(System.in);

        private String FirstName;
        private String LastName;
        private String ID;
        private String major;
        private String classStanding;
        private int gpa;
        private String courseLists;
        private String math;
        private String english;
        private String science;
        public Student(String FirstName, String LastName, String ID, String major, String classStanding, int gpa, String courseLists) {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.ID = ID;
            this.major = major;
            this.classStanding = classStanding;
            this.gpa = gpa;
            this.courseLists = courseLists;
        }
        private Course(String math, String english) {
            this.math = math;
            this.english = english;
            addCourse (String science) {
                Course.add(science);
            }
        }
        for (String key : Student.keySet()) {
        int value = Student.get(key);
        System.out.println(key + "'s score: " + value);
        Course.remove(math);
        }

        System.out.println(Student);
        System.out.println(Course);
}
