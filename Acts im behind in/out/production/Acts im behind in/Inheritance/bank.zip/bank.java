package Inheritance;

public class bank {
    public static void main(String[] args)
    {
        public int Money;
        public String Name;
        public int pin;
    }
    Integer pin = 3645;
    public void setMoney(30);

    private void getName("bartholomew") {
        setName("ben");
    }

    private void setName(String ben) {
    }
    System.out.println(pin);
    System.out.println(pin.toString());
}
