package Inheritance;

public class deposit {
    public static void main(String[] args)
    {
        public int Amount;
    }

    private void getAmount(13) {
        setAmount(12);
    }

    private void setAmount(int i) {


        boolean Amount;
        System.out.println(Amount.toString());
        System.out.println(Amount);
    }
}

