package Inheritance;

public class withdraw {
    public static void main(String[] args)
    {
        public int AmountTaken;
    }
    private void getAmountTaken(25) {
        setAmountTaken(80);
    }

    private void setAmountTaken(int i) {

        boolean AmountTaken;
        System.out.println(AmountTaken.toString());
        System.out.println(AmountTaken);
    }
}
