public class StudentMain {
    public static void main(String[] args) {
        StudentSet daniel = new StudentSet();
        daniel.addStudents();
        daniel.displayStudents();
    }
}