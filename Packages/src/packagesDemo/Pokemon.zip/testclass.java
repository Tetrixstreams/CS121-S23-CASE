package packagesDemo;

public class testclass {

    public static void main(String[] args) {
        Pokemon player1 = new Pokemon("geodude", "rock", 30, 45);
        System.out.printf("Your name is %s/n", player1.name());
        System.out.printf("Your type is %s/n", player1.type());

    (int[] ) {
        System.out.printf("Your damage is %s/n", player1.damage());
        System.out.printf("Your health is %s/n", player1.health());
        }
    }

}
