public class Main {
    public static void main(String[] args) {
        PokemonSelection PokemonSelection = new PokemonSelection();
         PokemonSelection.assignPokemon();
    }
}