public class Class2 {
    public int amount;
    public String animal;
    public String color;


        public Class2 (double amount, String animal, String color) {
            this.amount = (int) amount;
            this.animal = animal;
            this.color =  color;
        }
        public void color (String newColor) {
            color = newColor;
        }
    }

